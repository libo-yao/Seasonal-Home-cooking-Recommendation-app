移除页面中3处英文文字，使整体保持纯中式水墨风格：

1. **Hero 区域** — 删除节气标题上方的 `The Solar Terms` 小字
2. **今日食单卡片** — 删除标题下方的 `Dietary Prescription of the Day` 副标题
3. **底部黑条装饰** — 删除 `Balance & Harmony` 文字，保留装饰点

仅做删除操作，不涉及其他样式或布局改动。