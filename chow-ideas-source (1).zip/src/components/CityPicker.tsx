import { useEffect, useMemo, useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import {
  PRESET_CITIES,
  REGION_LABELS,
  searchCities,
  type GeoCity,
} from "@/lib/weather";

type Props = {
  value: GeoCity;
  onChange: (city: GeoCity) => void;
  /** trigger 显示文本：默认用 value.name */
  triggerLabel?: string;
};

export function CityPicker({ value, onChange, triggerLabel }: Props) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<GeoCity[]>([]);
  const [loading, setLoading] = useState(false);

  // 防抖搜索
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    const t = setTimeout(async () => {
      setLoading(true);
      try {
        const r = await searchCities(query);
        setResults(r);
      } finally {
        setLoading(false);
      }
    }, 300);
    return () => clearTimeout(t);
  }, [query]);

  const presetByRegion = useMemo(() => {
    const groups: Record<string, GeoCity[]> = {};
    for (const c of PRESET_CITIES) (groups[c.region] ||= []).push(c);
    return groups;
  }, []);

  const select = (c: GeoCity) => {
    onChange(c);
    setOpen(false);
    setQuery("");
    setResults([]);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="text-[11px] text-ink hover:underline px-1 leading-none"
          title="切换城市"
        >
          {triggerLabel ?? value.name}
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-72 p-0 rounded-sm">
        <div className="p-2 border-b border-border/60">
          <Input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索任意城市（盘锦、香港、Tokyo…）"
            className="h-8 text-xs rounded-sm"
          />
        </div>
        <div className="max-h-72 overflow-auto py-1">
          {query.trim() ? (
            <>
              {loading && (
                <p className="px-3 py-2 text-[11px] text-muted-foreground">搜索中…</p>
              )}
              {!loading && results.length === 0 && (
                <p className="px-3 py-2 text-[11px] text-muted-foreground">
                  无结果，可尝试英文名或换关键词
                </p>
              )}
              {results.map((c, i) => (
                <button
                  key={`${c.name}-${c.latitude}-${i}`}
                  onClick={() => select(c)}
                  className="w-full text-left px-3 py-1.5 text-xs hover:bg-accent/10 flex justify-between items-baseline"
                >
                  <span className="text-ink">{c.name}</span>
                  <span className="text-[10px] text-muted-foreground">
                    {[c.admin1, c.country].filter(Boolean).join(" · ") ||
                      REGION_LABELS[c.region]}
                  </span>
                </button>
              ))}
            </>
          ) : (
            <>
              <p className="px-3 pt-2 pb-1 text-[10px] text-muted-foreground tracking-widest">
                常用城市（可搜索任意城市）
              </p>
              {(Object.keys(presetByRegion) as Array<keyof typeof REGION_LABELS>).map(
                (rg) => (
                  <div key={rg}>
                    <p className="px-3 pt-1.5 text-[10px] text-cinnabar/70 tracking-wider">
                      {REGION_LABELS[rg]}
                    </p>
                    <div className="flex flex-wrap gap-1 px-3 pb-1.5 pt-1">
                      {presetByRegion[rg].map((c) => (
                        <button
                          key={c.name}
                          onClick={() => select(c)}
                          className={`text-[11px] px-1.5 py-0.5 border rounded-sm ${
                            value.name === c.name
                              ? "border-cinnabar text-cinnabar"
                              : "border-border/60 text-foreground/80 hover:border-cinnabar/60"
                          }`}
                        >
                          {c.name}
                        </button>
                      ))}
                    </div>
                  </div>
                ),
              )}
            </>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
