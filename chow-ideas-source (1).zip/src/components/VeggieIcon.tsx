// 根据地域 + 节气挑选一种当季蔬菜图标
// 每个图标都是 14x14 viewBox 的极简 SVG，filled 时表示当前活跃组

type VeggieKey =
  | "chili"     // 辣椒
  | "radish"    // 萝卜
  | "eggplant"  // 茄子
  | "cabbage"   // 白菜
  | "pumpkin"   // 南瓜
  | "mushroom"  // 香菇
  | "lotus"     // 莲藕
  | "corn"      // 玉米
  | "tomato"    // 番茄
  | "garlic"    // 蒜
  | "bambooShoot" // 春笋
  | "pea";      // 豌豆

// 节气 -> 该节气最当令的几种蔬菜（按地域偏好二次挑选）
const TERM_VEGGIES: Record<string, VeggieKey[]> = {
  立春: ["bambooShoot", "pea", "radish"],
  雨水: ["bambooShoot", "pea", "cabbage"],
  惊蛰: ["bambooShoot", "garlic", "pea"],
  春分: ["pea", "bambooShoot", "radish"],
  清明: ["pea", "bambooShoot", "garlic"],
  谷雨: ["pea", "cabbage", "mushroom"],
  立夏: ["cabbage", "tomato", "eggplant"],
  小满: ["tomato", "eggplant", "cabbage"],
  芒种: ["tomato", "eggplant", "chili"],
  夏至: ["tomato", "eggplant", "chili"],
  小暑: ["chili", "eggplant", "tomato"],
  大暑: ["chili", "tomato", "eggplant"],
  立秋: ["corn", "pumpkin", "eggplant"],
  处暑: ["corn", "pumpkin", "lotus"],
  白露: ["pumpkin", "lotus", "corn"],
  秋分: ["pumpkin", "lotus", "mushroom"],
  寒露: ["lotus", "pumpkin", "mushroom"],
  霜降: ["radish", "cabbage", "lotus"],
  立冬: ["radish", "cabbage", "mushroom"],
  小雪: ["cabbage", "radish", "mushroom"],
  大雪: ["cabbage", "radish", "garlic"],
  冬至: ["radish", "cabbage", "garlic"],
  小寒: ["garlic", "radish", "cabbage"],
  大寒: ["garlic", "cabbage", "radish"],
};

// 地域偏好——某些菜在某地更具代表性，优先选中
const REGION_PREF: Record<string, VeggieKey[]> = {
  northeast: ["cabbage", "radish", "corn", "mushroom"],
  north: ["garlic", "cabbage", "radish", "pea"],
  northwest: ["garlic", "pumpkin", "chili", "corn"],
  east: ["bambooShoot", "lotus", "tomato", "pea"],
  central: ["lotus", "chili", "eggplant", "pumpkin"],
  south: ["chili", "eggplant", "tomato", "mushroom"],
  southwest: ["chili", "mushroom", "bambooShoot", "eggplant"],
};

export function pickVeggie(termName: string, region: string): VeggieKey {
  const seasonal = TERM_VEGGIES[termName] ?? ["radish"];
  const prefs = REGION_PREF[region] ?? [];
  // 先在当季 list 中找地域偏好的交集
  for (const v of prefs) {
    if (seasonal.includes(v)) return v;
  }
  return seasonal[0];
}

function Paths({ kind, filled }: { kind: VeggieKey; filled: boolean }) {
  const f = filled ? "currentColor" : "none";
  const s = "currentColor";
  switch (kind) {
    case "chili":
      return (
        <>
          <path d="M5 2.5C3 2.5 1.5 4.5 1.5 7c0 2.5 1.5 4.5 3.5 4.5S8.5 9.5 8.5 7C8.5 4.5 7 2.5 5 2.5z" fill={f} stroke={s} strokeWidth="1" strokeLinejoin="round" transform="translate(2 1)" />
          <path d="M7 3.5V2" stroke={s} strokeWidth="1" strokeLinecap="round" fill="none" />
        </>
      );
    case "radish":
      // 白萝卜：圆头 + 叶
      return (
        <>
          <path d="M4 6c0-1.5 1.5-2.5 3-2.5S10 4.5 10 6c0 2-1.5 5-3 5S4 8 4 6z" fill={f} stroke={s} strokeWidth="1" strokeLinejoin="round" />
          <path d="M7 3.5c-0.5-1-1.5-1.5-2-1.5M7 3.5c0.5-1 1.5-1.5 2-1.5" stroke={s} strokeWidth="1" fill="none" strokeLinecap="round" />
        </>
      );
    case "eggplant":
      return (
        <>
          <path d="M4 7c0-2 1.5-3.5 3.5-3.5C9 3.5 10 4.5 10 5.5c0 2.5-2 6-4 6S3 9.5 4 7z" fill={f} stroke={s} strokeWidth="1" strokeLinejoin="round" />
          <path d="M6.5 3.5c-0.5-1-1-1.5-1.5-1.5M7.5 3.5c0.3-0.8 1-1.3 1.8-1.3" stroke={s} strokeWidth="1" fill="none" strokeLinecap="round" />
        </>
      );
    case "cabbage":
      return (
        <>
          <circle cx="7" cy="8" r="4" fill={f} stroke={s} strokeWidth="1" />
          <path d="M7 4v8M4 6.5c2 0.5 4 0.5 6 0M4 9.5c2 0.5 4 0.5 6 0" stroke={s} strokeWidth="0.7" fill="none" />
        </>
      );
    case "pumpkin":
      return (
        <>
          <ellipse cx="7" cy="8.5" rx="5" ry="3.5" fill={f} stroke={s} strokeWidth="1" />
          <path d="M5 5.5v6M7 5v7M9 5.5v6" stroke={s} strokeWidth="0.7" fill="none" />
          <path d="M7 5V3" stroke={s} strokeWidth="1" strokeLinecap="round" fill="none" />
        </>
      );
    case "mushroom":
      return (
        <>
          <path d="M2.5 7c0-2.5 2-4 4.5-4s4.5 1.5 4.5 4H2.5z" fill={f} stroke={s} strokeWidth="1" strokeLinejoin="round" />
          <path d="M5.5 7v4.5h3V7" fill={f} stroke={s} strokeWidth="1" strokeLinejoin="round" />
        </>
      );
    case "lotus":
      // 莲藕：横切三孔
      return (
        <>
          <ellipse cx="7" cy="7" rx="5.5" ry="3" fill={f} stroke={s} strokeWidth="1" />
          <circle cx="4.5" cy="7" r="0.7" fill="none" stroke={s} strokeWidth="0.7" />
          <circle cx="7" cy="7" r="0.7" fill="none" stroke={s} strokeWidth="0.7" />
          <circle cx="9.5" cy="7" r="0.7" fill="none" stroke={s} strokeWidth="0.7" />
        </>
      );
    case "corn":
      return (
        <>
          <path d="M7 1.5C5 1.5 4 4 4 7.5S5.5 12.5 7 12.5 10 11 10 7.5 9 1.5 7 1.5z" fill={f} stroke={s} strokeWidth="1" strokeLinejoin="round" />
          <path d="M5 4l4 0M5 6l4 0M5 8l4 0M5 10l4 0" stroke={s} strokeWidth="0.5" fill="none" />
        </>
      );
    case "tomato":
      return (
        <>
          <circle cx="7" cy="8" r="4" fill={f} stroke={s} strokeWidth="1" />
          <path d="M5 4.5l1 1.5M7 3.5v2.5M9 4.5l-1 1.5" stroke={s} strokeWidth="0.8" fill="none" strokeLinecap="round" />
        </>
      );
    case "garlic":
      return (
        <>
          <path d="M7 3.5c-2 0-3.5 2-3.5 4.5S5 12 7 12s3.5-1.5 3.5-4S9 3.5 7 3.5z" fill={f} stroke={s} strokeWidth="1" strokeLinejoin="round" />
          <path d="M7 3.5v8M5 5c0.5 2 0.5 5 0 7M9 5c-0.5 2-0.5 5 0 7" stroke={s} strokeWidth="0.5" fill="none" />
          <path d="M7 3.5V2" stroke={s} strokeWidth="1" strokeLinecap="round" fill="none" />
        </>
      );
    case "bambooShoot":
      return (
        <>
          <path d="M7 1.5l3 4.5-1.5 6h-3L4 6z" fill={f} stroke={s} strokeWidth="1" strokeLinejoin="round" />
          <path d="M5 5h4M5.5 7.5h3M6 10h2" stroke={s} strokeWidth="0.6" fill="none" />
        </>
      );
    case "pea":
      return (
        <>
          <path d="M2 8c0-2.5 2-4.5 5-4.5s5 2 5 4.5c0 1-1 2-2 2H4c-1 0-2-1-2-2z" fill={f} stroke={s} strokeWidth="1" strokeLinejoin="round" />
          <circle cx="5" cy="7.5" r="0.9" fill="none" stroke={s} strokeWidth="0.6" />
          <circle cx="7" cy="7.5" r="0.9" fill="none" stroke={s} strokeWidth="0.6" />
          <circle cx="9" cy="7.5" r="0.9" fill="none" stroke={s} strokeWidth="0.6" />
        </>
      );
  }
}

export function VeggieIcon({
  kind,
  filled,
  className,
}: {
  kind: VeggieKey;
  filled: boolean;
  className?: string;
}) {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" className={className}>
      <Paths kind={kind} filled={filled} />
    </svg>
  );
}
