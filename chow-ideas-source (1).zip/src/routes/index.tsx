import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  PRESET_CITIES,
  REGION_LABELS,
  fetchWeather,
  weatherCodeText,
  type GeoCity,
} from "@/lib/weather";
import {
  getCurrentSolarTerm,
  getNextSolarTerm,
  getCurrentHou,
} from "@/lib/solar-terms";
import { inferWeatherTags, recommendMenu, maxRerollGroups } from "@/lib/recommend";
import {
  requestGeolocation,
  reverseGeocodeToCity,
  getTermProgress,
} from "@/lib/location";
import { Button } from "@/components/ui/button";
import { CityPicker } from "@/components/CityPicker";

import { toast } from "sonner";
import { VeggieIcon, pickVeggie } from "@/components/VeggieIcon";

const STORAGE_KEY = "jrsd_city_v2";
const MANUAL_KEY = "jrsd_city_manual";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "今日食单 · 按节气与天气推荐家常菜" },
      {
        name: "description",
        content: "二十四节气 × 当地天气 × 中医食补，按本地食材推荐一日三餐。每天告诉你今天该做什么菜。",
      },
      { property: "og:title", content: "今日食单 · 按节气与天气推荐家常菜" },
      {
        property: "og:description",
        content: "二十四节气 × 当地天气 × 中医食补，按本地食材推荐一日三餐。",
      },
    ],
  }),
  component: TodayMenu,
});

function TodayMenu() {
  const [city, setCity] = useState<GeoCity>(() => PRESET_CITIES[0]);

  // 加载本地存储的城市
  useEffect(() => {
    if (typeof window === "undefined") return;
    const raw = localStorage.getItem(STORAGE_KEY);
    const manualSet = localStorage.getItem(MANUAL_KEY) === "1";
    if (raw) {
      try {
        const saved = JSON.parse(raw) as GeoCity;
        if (saved && typeof saved.latitude === "number") {
          setCity(saved);
          if (manualSet) return;
        }
      } catch {
        /* ignore */
      }
    }
    // 自动定位（反向地理 → 真实城市）
    requestGeolocation()
      .then(async ({ lat, lon }) => {
        const c = await reverseGeocodeToCity(lat, lon);
        setCity(c);
        toast.success(`已定位到 ${c.name}`, {
          description: c.admin1 || c.country || "可点击城市名手动切换",
        });
      })
      .catch(() => {
        /* 静默失败：保留默认/已存城市 */
      });
  }, []);

  const handleCityChange = (c: GeoCity) => {
    setCity(c);
    if (typeof window !== "undefined") {
      localStorage.setItem(MANUAL_KEY, "1");
    }
  };

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(city));
    }
  }, [city]);

  const today = new Date();
  const dateKey = today.toISOString().slice(0, 10);
  const term = getCurrentSolarTerm(today);
  const next = getNextSolarTerm(today);
  const hou = getCurrentHou(today);
  const progress = getTermProgress(today);

  const { data: weather, isLoading, refetch, isFetching } = useQuery({
    queryKey: ["weather", city.latitude, city.longitude],
    queryFn: () => fetchWeather(city),
    staleTime: 30 * 60 * 1000,
  });

  const [reroll, setReroll] = useState(0);
  const groupCount = useMemo(() => maxRerollGroups(city.region), [city.region]);
  const safeReroll = reroll % groupCount;
  const menu = useMemo(() => {
    const tags = weather
      ? inferWeatherTags({
          tempC: weather.tempC,
          precipitation: weather.precipitation,
          weatherCode: weather.weatherCode,
          humidity: weather.humidity,
          windSpeed: weather.windSpeed,
        })
      : ["mild" as const];
    return recommendMenu(term, tags, city.region, `${dateKey}|${city.name}`, safeReroll, hou.index);
  }, [weather, term, dateKey, city.name, city.region, safeReroll, hou.index]);

  const dateText = formatChineseDate(today);



  return (
    <main className="min-h-screen px-4 py-6 sm:py-10 relative overflow-hidden">
      {/* 背景大字水印 */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 flex items-center justify-center select-none"
      >
        <span className="calligraphy text-[42vh] text-foreground/[0.025] leading-none">
          {term.name[0]}
        </span>
      </div>

      <div className="mx-auto max-w-[480px] relative">
        {/* ============ HERO: 节气巨幅 ============ */}
        <section className="relative pt-4 pb-8">
          {/* 装饰水墨 SVG */}
          <svg
            aria-hidden
            viewBox="0 0 200 200"
            className="absolute -top-4 -right-8 w-44 h-44 opacity-[0.08] pointer-events-none"
          >
            <path
              fill="currentColor"
              d="M44.7,-76.4C58.1,-69.2,69.1,-57.4,76.4,-44C83.7,-30.6,87.2,-15.3,86.2,-0.6C85.2,14.1,79.7,28.2,71.2,40.4C62.7,52.6,51.2,62.8,38,69.5C24.8,76.2,9.9,79.3,-5,88C-19.9,96.7,-34.8,111,-47.1,107.5C-59.4,104,-69.1,82.7,-76.1,65.6C-83.1,48.5,-87.4,35.6,-89.7,22.4C-92,9.2,-92.3,-4.3,-88.1,-16.4C-83.9,-28.5,-75.2,-39.2,-64.5,-48C-53.8,-56.8,-41.1,-63.7,-28.7,-71.4C-16.3,-79.1,-4.2,-87.6,9.6,-83.1C23.4,-78.6,31.3,-83.6,44.7,-76.4Z"
              transform="translate(100 100)"
            />
          </svg>

          <div className="flex justify-between items-start mb-5">
            <div className="ink-rise">
              <div className="flex items-end gap-3">
                <h1 className="calligraphy text-7xl text-ink">{term.name}</h1>
                <div className="pb-2 border-l border-border pl-3 text-xs text-muted-foreground leading-relaxed">
                  <p>第{["一", "二", "三"][hou.index - 1]}候</p>
                  <p className="text-cinnabar">{hou.name}</p>
                </div>
              </div>
              <p className="text-[11px] text-muted-foreground mt-2 tracking-wider">
                距 <span className="text-foreground">{next.name}</span> 还有{" "}
                <span className="text-cinnabar font-bold">{progress.daysToNext}</span> 天
              </p>
            </div>

            {/* 朱砂双框印章 */}
            <div className="seal-square w-14 h-14 seal-drop shrink-0">
              <span className="text-xs leading-tight">
                食养<br />正气
              </span>
            </div>
          </div>

          {/* 日期 + 所在地 一行 */}
          <div className="flex items-center justify-between text-[11px] text-muted-foreground border-y border-border/60 py-2.5">
            <span className="font-serif">{dateText}</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  requestGeolocation()
                    .then(async ({ lat, lon }) => {
                      const c = await reverseGeocodeToCity(lat, lon);
                      setCity(c);
                      if (typeof window !== "undefined") {
                        localStorage.removeItem(MANUAL_KEY);
                      }
                      toast.success(`已定位到 ${c.name}`, {
                        description: c.admin1 || c.country,
                      });
                    })
                    .catch(() => toast.error("定位失败，请检查浏览器权限"));
                }}
                className="text-cinnabar"
                title="重新定位"
              >
                <svg viewBox="0 0 14 14" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="7" cy="7" r="6" />
                  <path d="M7 3v2.5" /><path d="M7 8.5V11" />
                  <path d="M3 7h2.5" /><path d="M8.5 7H11" />
                  <ellipse cx="7" cy="7" rx="1.8" ry="3.2" transform="rotate(45 7 7)" />
                </svg>
              </button>
              <CityPicker value={city} onChange={handleCityChange} />
            </div>
          </div>


          {/* 天气信息 */}
          {weather ? (
            <div className="flex items-end justify-between mt-4">
              <div>
                <p className="font-serif text-base text-foreground">
                  {weather.cityLabel} · {weatherCodeText(weather.weatherCode)}
                </p>
                <p className="text-[11px] text-muted-foreground mt-1">
                  {Math.round(weather.tempC)}℃ · 湿度 {weather.humidity}% · 风 {Math.round(weather.windSpeed)} km/h
                </p>
                <p className="text-[11px] text-accent mt-1">
                  菜系倾向 · {REGION_LABELS[city.region]}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => refetch()}
                disabled={isFetching}
                className="h-6 px-2 text-[10px] text-cinnabar hover:text-cinnabar hover:bg-cinnabar/10 tracking-widest"
              >
                重新感知
              </Button>
            </div>
          ) : (
            <p className="text-xs text-muted-foreground mt-4">{isLoading ? "正在感知天候…" : "—"}</p>
          )}
        </section>

        {/* ============ 主卡片：今日食单 ============ */}
        <section className="relative bg-card rounded-sm shadow-[var(--shadow-paper)] border border-border/70 px-7 pt-8 pb-7 ink-rise" style={{ animationDelay: "0.15s" }}>
          {/* 标题区 */}
          <div className="mb-7 pb-4 border-b border-border/50 flex items-baseline justify-between">
            <div>
              <h2 className="calligraphy text-4xl text-ink">今日食单</h2>
            </div>
            <span className="seal text-xs">膳</span>
          </div>

          {/* 推荐理由 */}
          <p className="font-serif text-sm leading-relaxed text-foreground/75 mb-7 italic">
            「{menu.rationale}」
          </p>

          {/* 三道菜 */}
          <div className="space-y-6">
            {[
              { label: "汤", role: "羹汤", dish: menu.soup },
              { label: "荤", role: "主菜", dish: menu.meat },
              { label: "素", role: "时蔬", dish: menu.veg },
            ].map(({ label, role, dish }, idx) => (
              <article key={label} className="group relative ink-rise" style={{ animationDelay: `${0.25 + idx * 0.08}s` }}>
                <div className="absolute -left-3 -top-3 calligraphy text-5xl text-foreground/[0.06] select-none pointer-events-none">
                  {["壹", "贰", "叁"][idx]}
                </div>
                <div className="relative pl-2">
                  <div className="flex items-baseline justify-between gap-3 mb-1">
                    <div className="flex items-baseline gap-2">
                      <span className="text-[10px] text-cinnabar font-bold border border-cinnabar px-1.5 py-0.5">
                        {label}
                      </span>
                      <h3 className="font-serif text-xl font-black text-ink tracking-tight">
                        {dish.name}
                      </h3>
                    </div>
                    <span className="text-[10px] text-muted-foreground tracking-widest shrink-0">
                      {role}
                    </span>
                  </div>
                  <p className="text-[11px] text-muted-foreground font-serif pl-1 mt-2">
                    {dish.ingredients.join(" · ")}
                  </p>
                  <p className="text-xs text-foreground/70 font-serif leading-relaxed mt-1.5 pl-1 italic">
                    " {dish.reason} "
                  </p>
                </div>
              </article>
            ))}
          </div>

          {/* 时令医案 */}
          <div className="mt-9 pt-5 border-t border-border/40">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-5 h-px bg-cinnabar" />
              <span className="text-[10px] text-cinnabar font-bold tracking-[0.3em]">
                时令医案
              </span>
            </div>
            <p className="text-xs text-foreground/65 font-serif leading-relaxed">
              「{hou.name}」· {term.phenology}
            </p>
          </div>

          {/* 换一组 */}
          <div className="mt-7 flex justify-center">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setReroll((n) => (n + 1) % groupCount)}
              className="border-cinnabar/40 text-cinnabar hover:bg-cinnabar hover:text-primary-foreground rounded-none text-xs tracking-[0.3em] px-6"
            >
              <svg viewBox="0 0 14 14" className="h-3 w-3 mr-2" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="7" cy="7" r="6" />
                <path d="M7 1A3 3 0 0 1 7 7A3 3 0 0 0 7 13" />
                <circle cx="7" cy="4" r="1" fill="currentColor" stroke="none" />
                <circle cx="7" cy="10" r="1" fill="currentColor" stroke="none" />
              </svg>
              换 · 一 · 组
            </Button>
          </div>

          {/* 时令进度点 */}
          <div className="mt-6 flex justify-center gap-1.5" title={`本季 · ${REGION_LABELS[city.region]}时蔬`}>
            {Array.from({ length: groupCount }).map((_, i) => (
              <VeggieIcon
                key={i}
                kind={pickVeggie(term.name, city.region)}
                filled={i === safeReroll}
                className={i === safeReroll ? "text-cinnabar" : "text-foreground/20"}
              />
            ))}
          </div>
        </section>

        {/* ============ 黑底装饰条 ============ */}
        <div className="mt-6 bg-ink text-rice/70 px-5 py-2.5 flex items-center justify-center rounded-sm">
          <div className="flex gap-1">
            <div className="w-1 h-1 rounded-full bg-rice/40" />
            <div className="w-1 h-1 rounded-full bg-rice/40" />
            <div className="w-1 h-1 rounded-full bg-cinnabar" />
          </div>
        </div>

        <footer className="mt-6 text-center text-[10px] text-muted-foreground tracking-[0.3em]">
          <p>食养有道 · 应时而食</p>
          <p className="mt-1 opacity-60">节气推算 + Open-Meteo</p>
        </footer>
      </div>
    </main>
  );
}

function formatChineseDate(d: Date): string {
  const weekdays = ["日", "一", "二", "三", "四", "五", "六"];
  return `${d.getFullYear()}年 ${d.getMonth() + 1}月 ${d.getDate()}日 · 星期${weekdays[d.getDay()]}`;
}
