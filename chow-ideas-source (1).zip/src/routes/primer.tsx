import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/primer")({
  head: () => ({
    meta: [
      { title: "食养小课 · 节气、物候、天人相应入门" },
      {
        name: "description",
        content: "用大白话讲清楚二十四节气、七十二候、不时不食、天人相应、司岁备物——古人怎样把饮食和自然连在一起。",
      },
      { property: "og:title", content: "食养小课" },
      {
        property: "og:description",
        content: "用大白话讲清楚二十四节气、七十二候、不时不食、天人相应、司岁备物。",
      },
    ],
  }),
  component: Primer,
});

const LESSONS: Array<{
  title: string;
  source?: string;
  body: string;
  takeaway: string;
}> = [
  {
    title: "节气",
    source: "源自《淮南子·天文训》",
    body:
      "古人把太阳一年走过的圆轨道分成 24 段，每 15 度一段，给每段起了一个名字——这就是二十四节气。它不是日期，是太阳在天上的位置。所以节气年年准，对应的气候、物产、身体状态也基本稳定。",
    takeaway: "看节气就是看「这段时间天地在做什么」。",
  },
  {
    title: "物候",
    source: "三候为一气，七十二候在《逸周书》中已有记载",
    body:
      "每个节气再分成三候，每候 5 天，共 72 候。古人观察到：每一候都有一个固定的自然信号——比如「立春」三候是「东风解冻 · 蛰虫始振 · 鱼陟负冰」。物候就是这些「自然界的告示牌」，比节气更细。",
    takeaway: "物候是看「自然给的具体信号」——燕子来了、蝉鸣了、桃花开了。",
  },
  {
    title: "不时不食",
    source: "《论语·乡党》：「不时，不食」",
    body:
      "孔子吃饭有规矩：不是当令的食物，他不吃。原因很朴素——应季的食材最便宜、最好吃、最有营养，也最契合此刻身体的需要。春天的笋鲜嫩、夏天的瓜多汁、秋天的蟹肥美、冬天的萝卜赛人参，都是这个道理。",
    takeaway: "尽量吃当地、当季的食材，错不了。",
  },
  {
    title: "天人相应",
    source: "《黄帝内经·素问》",
    body:
      "中医认为人是自然的一部分，身体随四季变化：春夏阳气向外（容易出汗、上火），秋冬阳气向内（容易怕冷、干燥）。所以「冬吃萝卜夏吃姜」——夏天吃点姜把内里温住，冬天吃点萝卜把外热散开，反着来反而平衡。",
    takeaway: "吃东西不是单看「补什么」，而是看「现在身体需要顺着什么」。",
  },
  {
    title: "司岁备物",
    source: "《黄帝内经·素问·五常政大论》",
    body:
      "「司」是掌管，「岁」是一年。意思是：每年的气候都不太一样（暖冬、寒冬、多雨、干旱），饮食和药材也要跟着调整。比如今年湿气重，就多备健脾祛湿的薏米、赤小豆；今年燥气盛，就多备润肺的银耳、百合。",
    takeaway: "古人讲究「看天吃饭」——今日食单做的就是把这件事自动化。",
  },
  {
    title: "五味与五脏",
    source: "《黄帝内经》「五味入五脏」",
    body:
      "酸入肝、苦入心、甘入脾、辛入肺、咸入肾。配合四季：春养肝（少酸多甘）、夏养心（清淡微苦）、秋养肺（润燥微辛）、冬养肾（温补带咸）。这就是食单为什么夏天推绿豆苦瓜、冬天推羊肉桂圆。",
    takeaway: "五味平衡是底层逻辑，不需要硬背，应季吃自然就对了。",
  },
];

function Primer() {
  return (
    <main className="min-h-screen px-4 py-10 sm:py-16">
      <div className="mx-auto max-w-3xl">
        {/* 顶部返回 */}
        <div className="mb-8">
          <Link
            to="/"
            className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors tracking-widest"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            回到今日食单
          </Link>
        </div>

        {/* Header */}
        <header className="mb-12 text-center">
          <div className="flex items-baseline justify-center gap-3 mb-4">
            <h1 className="ink-title text-5xl sm:text-6xl tracking-widest">食养小课</h1>
            <span className="seal">学</span>
          </div>
          <p className="text-sm text-muted-foreground tracking-widest">
            读懂古人讲了几千年的吃饭智慧
          </p>
          <div className="brush-divider w-40 mx-auto mt-4" />
        </header>

        {/* 开篇语 */}
        <section className="paper-card rounded-md p-7 sm:p-9 mb-10">
          <p className="font-serif leading-loose text-lg text-foreground/85">
            中国人讲究吃饭，不只是讲究好吃。背后是一整套观察自然、安顿身体的智慧——
            <span className="text-primary font-medium">看天时、应物候、合身体</span>。
            这些道理写在《黄帝内经》《论语》《淮南子》里，朴素但管用。
          </p>
          <p className="font-serif leading-loose text-base text-foreground/70 mt-4">
            下面六个关键词，是看懂「今日食单」推荐逻辑的钥匙——也是中国家常菜真正的味道来源。
          </p>
        </section>

        {/* 课程列表 */}
        <div className="space-y-8">
          {LESSONS.map((lesson, i) => (
            <article key={lesson.title} className="paper-card rounded-md p-7 sm:p-9 relative">
              {/* 章节号 */}
              <span className="absolute -top-3 left-7 px-3 py-1 bg-background text-primary font-display text-sm tracking-widest border border-primary/30 rounded-sm">
                第 {["一", "二", "三", "四", "五", "六"][i]} 讲
              </span>

              <div className="flex items-baseline gap-4 mb-4 mt-2">
                <h2 className="ink-title text-3xl sm:text-4xl text-ink">{lesson.title}</h2>
                {lesson.source && (
                  <p className="text-xs text-muted-foreground italic">{lesson.source}</p>
                )}
              </div>

              <p className="font-serif leading-loose text-foreground/85 mb-5">
                {lesson.body}
              </p>

              <div className="border-l-2 border-accent pl-4 py-1">
                <p className="text-xs text-accent tracking-widest mb-1">一句话记住</p>
                <p className="font-serif text-foreground/90">{lesson.takeaway}</p>
              </div>
            </article>
          ))}
        </div>

        {/* 结语 */}
        <section className="mt-14 text-center">
          <div className="brush-divider w-32 mx-auto mb-6" />
          <p className="font-serif text-lg text-foreground/80 leading-loose max-w-xl mx-auto">
            读懂这几个词，你就能看出每道菜推荐背后的道理。<br />
            不必字字精通——心里有数，做饭便有了底气。
          </p>
          <div className="mt-8">
            <Link
              to="/"
              className="inline-block px-6 py-2.5 bg-primary text-primary-foreground font-display tracking-widest text-sm rounded-sm hover:bg-primary/90 transition-colors"
            >
              回去看今日推荐
            </Link>
          </div>
        </section>

        <footer className="mt-16 text-center text-xs text-muted-foreground tracking-widest opacity-60">
          内容综合参考《黄帝内经》《论语》《淮南子》及现代节气食养著述
        </footer>
      </div>
    </main>
  );
}
