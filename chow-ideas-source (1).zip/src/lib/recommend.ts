import { DISHES, type Dish, type WeatherTag } from "./dishes";
import type { Region, SolarTerm } from "./solar-terms";
import { getPhenologyIngredients } from "./phenology";

export function inferWeatherTags(opts: {
  tempC: number;
  precipitation: number;
  weatherCode: number;
  humidity: number;
  windSpeed: number;
}): WeatherTag[] {
  const tags: WeatherTag[] = [];
  const { tempC, precipitation, weatherCode, humidity, windSpeed } = opts;

  if (tempC >= 28) tags.push("hot");
  else if (tempC <= 5) tags.push("cold");
  else tags.push("mild");

  if (humidity >= 75 && tempC >= 20) tags.push("humid");
  if (humidity <= 35) tags.push("dry");

  if ([71, 73, 75, 77, 85, 86].includes(weatherCode) || (precipitation > 0 && tempC <= 0)) {
    tags.push("snow");
  } else if (precipitation > 0.3 || [51, 53, 55, 61, 63, 65, 80, 81, 82, 95].includes(weatherCode)) {
    tags.push("rainy");
  }

  if (windSpeed >= 25) tags.push("windy");

  return tags;
}

type Intent = {
  rationale: string;
  recommend: string[];
  avoid: string[];
  phenology: string[];
  phenologyName: string;
  weatherWord: string;
};

function buildIntent(
  term: SolarTerm,
  tags: WeatherTag[],
  region: Region,
  houIndex: 1 | 2 | 3 = 1,
): Intent {
  const has = (t: WeatherTag) => tags.includes(t);
  const southern = region === "south" || region === "southwest" || region === "jiangnan";
  const northern = region === "northeast" || region === "northwest" || region === "north";

  let weatherWord = "";
  let advice = "";
  let recommend: string[] = [];
  const HOT_TONIC = ["羊肉", "桂圆", "当归", "肉桂", "花椒", "辣椒", "牛肉"];
  const COLD_FOOD = ["绿豆", "苦瓜", "西瓜", "雪梨", "冰糖", "莲藕生"];
  let avoid: string[] = [];

  if (has("hot") && has("humid")) {
    weatherWord = "湿热";
    advice = southern ? "宜清热祛湿，食绿豆、冬瓜、薏米" : "宜清补祛湿，食薏米、苦瓜、绿豆";
    recommend = ["绿豆", "冬瓜", "薏米", "苦瓜", "丝瓜", "扁豆"];
    avoid = HOT_TONIC;
  } else if (has("hot") && has("dry")) {
    weatherWord = "燥热";
    advice = "宜清热生津，食西瓜、银耳、雪梨";
    recommend = ["西瓜", "银耳", "雪梨", "百合", "莲子", "藕", "蜂蜜"];
    avoid = HOT_TONIC;
  } else if (has("hot")) {
    weatherWord = "暑热";
    advice = "宜清暑解热，食绿豆、苦瓜、酸梅";
    recommend = ["绿豆", "苦瓜", "酸梅", "冬瓜", "丝瓜", "莲子"];
    avoid = HOT_TONIC;
  } else if (has("cold") && has("snow")) {
    weatherWord = "冰雪";
    advice = "宜温阳御寒，食羊肉、姜枣、桂圆";
    recommend = ["羊肉", "姜", "红枣", "桂圆", "核桃", "牛肉"];
    avoid = COLD_FOOD;
  } else if (has("cold")) {
    weatherWord = "严寒";
    advice = northern ? "宜温补暖身，食牛肉、羊肉、山药" : "宜暖中补气，食羊肉、生姜、红枣";
    recommend = northern
      ? ["牛肉", "羊肉", "山药", "土豆", "白菜", "萝卜"]
      : ["羊肉", "生姜", "红枣", "山药", "鸡"];
    avoid = COLD_FOOD;
  } else if (has("rainy") && has("humid")) {
    weatherWord = "阴湿";
    advice = "宜健脾化湿，食薏米、赤小豆、山药";
    recommend = ["薏米", "赤小豆", "山药", "茯苓", "扁豆", "芡实"];
  } else if (has("rainy")) {
    weatherWord = "微雨";
    advice = "宜温润和胃，食生姜、山药、香菇";
    recommend = ["生姜", "姜", "山药", "香菇", "鸡"];
  } else if (has("snow")) {
    weatherWord = "落雪";
    advice = "宜温补抗寒，食羊肉、核桃、桂圆";
    recommend = ["羊肉", "核桃", "桂圆", "红枣", "牛肉"];
    avoid = COLD_FOOD;
  } else if (has("dry")) {
    weatherWord = "干燥";
    advice = "宜滋阴润燥，食银耳、百合、雪梨";
    recommend = ["银耳", "百合", "雪梨", "梨", "蜂蜜", "藕", "白萝卜"];
    avoid = HOT_TONIC;
  } else if (has("humid")) {
    weatherWord = "湿润";
    advice = "宜健脾祛湿，食薏米、冬瓜、扁豆";
    recommend = ["薏米", "冬瓜", "扁豆", "赤小豆", "山药"];
  } else if (has("windy")) {
    weatherWord = "风疾";
    advice = "宜润燥护肺，食梨、银耳、蜂蜜";
    recommend = ["梨", "银耳", "蜂蜜", "百合", "白萝卜"];
  }

  const phenologyName = term.candidates[houIndex - 1];
  const phenology = getPhenologyIngredients(phenologyName);
  const phenoTip = phenology.length > 0 ? `物候「${phenologyName}」宜${phenology.slice(0, 3).join("、")}` : "";

  const rationale = weatherWord
    ? `今日${term.name}·${weatherWord}，${advice}。${phenoTip}。`
    : `今日${term.name}，${term.guidance}${phenoTip ? "；" + phenoTip : ""}。`;

  return {
    rationale,
    recommend: [...recommend, ...phenology],
    avoid,
    phenology,
    phenologyName,
    weatherWord,
  };
}

export type DailyMenu = {
  soup: Dish;
  meat: Dish;
  veg: Dish;
  matchedTags: WeatherTag[];
  rationale: string;
};

function dishFitsRegion(dish: Dish, region: Region): boolean {
  return dish.regions === "all" || dish.regions.includes(region);
}

function isLocal(dish: Dish, region: Region): boolean {
  return dish.regions !== "all" && (dish.regions as Region[]).includes(region);
}

function conflictsWith(
  dish: Dish,
  term: SolarTerm,
  weatherTags: WeatherTag[],
): boolean {
  const has = (t: WeatherTag) => weatherTags.includes(t);
  const dw = new Set(dish.weather);

  if ((has("hot") || term.season === "summer") && (dw.has("cold") || dw.has("snow"))) return true;
  if ((has("cold") || has("snow") || term.season === "winter") && dw.has("hot")) return true;
  if (has("dry") && dw.has("cold") && dw.has("snow")) return true;

  if (dish.seasons.length === 1) {
    const only = dish.seasons[0];
    const opposite =
      (only === "summer" && term.season === "winter") ||
      (only === "winter" && term.season === "summer");
    if (opposite) return true;
  }
  return false;
}

function ingredientText(dish: Dish): string {
  return dish.ingredients.join("|") + "|" + dish.reason + "|" + dish.name;
}

function matchesAny(dish: Dish, keys: string[]): boolean {
  if (keys.length === 0) return false;
  const text = ingredientText(dish);
  return keys.some((k) => text.includes(k));
}

// 三层评分：节气物候 > 天气 > 地域可得性
function scoreDish(
  dish: Dish,
  term: SolarTerm,
  weatherTags: WeatherTag[],
  region: Region,
  intent: Intent,
): number {
  let score = 0;

  // 第一层：节气+物候（权重最高）
  const phenologyHits = intent.phenology.filter((k) => ingredientText(dish).includes(k)).length;
  score += phenologyHits * 10;
  if (dish.seasons.includes(term.season)) score += 5;
  else score -= 3;

  // 第二层：天气
  const weatherHits = dish.weather.filter((w) => weatherTags.includes(w)).length;
  score += weatherHits * 4;
  if (weatherHits === 0 && !dish.weather.includes("mild")) score -= 1;
  const intentHits = intent.recommend.filter((k) => ingredientText(dish).includes(k)).length;
  score += intentHits * 3;

  // 第三层：地域+可得性（强加权地域，减少"all"通用菜出现）
  // 地域权重大幅提升：本地菜远超通用菜，外地菜显著降权
  if (isLocal(dish, region)) {
    score += 18;
    if (dish.availability === 1) score += 8; // 强地域性食材额外重赏
    else if (dish.availability === 2) score += 3;
  } else if (dish.regions === "all") {
    score -= 3; // 通用菜降权，让本地特色更易胜出
  } else {
    score -= 8; // 外地菜显著降权（仅物候兜底时才会入选）
  }
  score += dish.availability * 0.4;

  return score;
}

type CategoryPool = {
  cat: Dish["category"];
  ranked: Dish[]; // 已按分数排序，含足够多的候选以保证不重复
};

function buildCategoryPool(
  cat: Dish["category"],
  term: SolarTerm,
  weatherTags: WeatherTag[],
  region: Region,
  intent: Intent,
): CategoryPool {
  // 候选 = 适配本地域 ∪ 物候命中(跨域兜底)
  const inRegion = DISHES.filter((d) => d.category === cat && dishFitsRegion(d, region));
  const phenoCross =
    intent.phenology.length > 0
      ? DISHES.filter(
          (d) =>
            d.category === cat &&
            !dishFitsRegion(d, region) &&
            matchesAny(d, intent.phenology),
        )
      : [];
  const all = [...inRegion, ...phenoCross];

  // 剔除天气硬冲突与"应避食材"
  const compatible = all.filter(
    (d) => !conflictsWith(d, term, weatherTags) && !matchesAny(d, intent.avoid),
  );
  const fallback = all.filter((d) => !conflictsWith(d, term, weatherTags));
  const candidates =
    compatible.length > 0 ? compatible : fallback.length > 0 ? fallback : all;

  const ranked = candidates
    .map((d) => ({ d, s: scoreDish(d, term, weatherTags, region, intent) }))
    .sort((a, b) => b.s - a.s)
    .map((r) => r.d);

  return { cat, ranked: ranked.length > 0 ? ranked : DISHES.filter((d) => d.category === cat) };
}

function seededOffset(seed: string, mod: number): number {
  if (mod <= 0) return 0;
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return h % mod;
}

// 构建 N 组互不重复的推荐
export function recommendMenuGroups(
  term: SolarTerm,
  weatherTags: WeatherTag[],
  region: Region,
  dateKey: string,
  houIndex: 1 | 2 | 3 = 1,
  groupCount: number = 3,
): DailyMenu[] {
  const intent = buildIntent(term, weatherTags, region, houIndex);

  const pools = (["soup", "meat", "veg"] as const).map((cat) =>
    buildCategoryPool(cat, term, weatherTags, region, intent),
  );

  // 每个分类按种子偏移，保证日期不同时起点不同
  const offsets = pools.map((p) => seededOffset(`${dateKey}|${p.cat}`, Math.max(1, p.ranked.length)));

  const groups: DailyMenu[] = [];
  // 跨组去重：每个分类独立记录已用 dish
  const used: Set<string>[] = pools.map(() => new Set());

  for (let g = 0; g < groupCount; g++) {
    const picks: Dish[] = pools.map((p, i) => {
      const ranked = p.ranked;
      // 从 offset+g 起向后扫描第一个未用过的菜
      for (let step = 0; step < ranked.length; step++) {
        const idx = (offsets[i] + g + step) % ranked.length;
        const d = ranked[idx];
        if (!used[i].has(d.name)) {
          used[i].add(d.name);
          return d;
        }
      }
      // 候选不足时复用首选（极少触发）
      return ranked[0];
    });

    groups.push({
      soup: picks[0],
      meat: picks[1],
      veg: picks[2],
      matchedTags: weatherTags,
      rationale: intent.rationale,
    });
  }

  return groups;
}

// 兼容旧 API
export function recommendMenu(
  term: SolarTerm,
  weatherTags: WeatherTag[],
  region: Region,
  dateKey: string,
  rerollIndex: number = 0,
  houIndex: 1 | 2 | 3 = 1,
): DailyMenu {
  const total = maxRerollGroups(region);
  const groups = recommendMenuGroups(term, weatherTags, region, dateKey, houIndex, total);
  return groups[rerollIndex % groups.length];
}

// 可用组数 = 各分类候选最少者，封顶 5，保证每组互不重复
export function maxRerollGroups(region: Region): number {
  const cats: Dish["category"][] = ["soup", "meat", "veg"];
  let min = Infinity;
  for (const cat of cats) {
    const inRegion = DISHES.filter((d) => d.category === cat && dishFitsRegion(d, region));
    // 优先以"本地菜"数为上限（强化地域），但若本地菜不足 3 道，则放宽到全部可用
    const localCount = inRegion.filter((d) => isLocal(d, region)).length;
    const usable = localCount >= 3 ? localCount : inRegion.length;
    if (usable < min) min = usable;
  }
  return Math.max(1, Math.min(5, min));
}
