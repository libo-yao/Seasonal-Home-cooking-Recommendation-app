// 二十四节气 + 七十二候 + 五行养生
export type Region =
  | "northeast" // 东北
  | "north"     // 华北
  | "jiangnan"  // 江南
  | "south"     // 华南
  | "southwest" // 西南
  | "northwest" // 西北
  | "central"   // 华中
  | "hongkong"  // 港澳
  | "taiwan"    // 台湾
  | "overseas"; // 海外（通用时令推荐）

export type SolarTerm = {
  name: string;
  pinyin: string;
  start: [number, number];
  season: "spring" | "summer" | "autumn" | "winter";
  themes: string[];
  phenology: string;           // 三候简述
  candidates: [string, string, string]; // 三候名称
  explanations: [string, string, string]; // 三候白话解释
  climate: string;              // 气候描述
  guidance: string;             // 饮食建议
};

export const SOLAR_TERMS: SolarTerm[] = [
  { name: "立春", pinyin: "Lichun", start: [2, 4], season: "spring", themes: ["升发", "养肝", "辛甘"],
    candidates: ["东风解冻", "蛰虫始振", "鱼陟负冰"],
    explanations: ["东风送暖，大地开始解冻", "冬眠的虫子开始苏醒振动", "鱼儿游到水面，像背着碎冰"],
    climate: "阳气始升，东风送暖",
    phenology: "东风解冻，蛰虫始振，鱼陟负冰",
    guidance: "宜食辛甘发散之品，少酸多甘以养脾" },
  { name: "雨水", pinyin: "Yushui", start: [2, 19], season: "spring", themes: ["养肝", "健脾", "祛湿"],
    candidates: ["獭祭鱼", "候雁北", "草木萌动"],
    explanations: ["水獭捕到鱼后排列在岸边，像祭祀", "大雁从南方飞回北方", "草木开始抽出嫩芽"],
    climate: "降雨增多，地气升腾",
    phenology: "獭祭鱼，候雁北，草木萌动",
    guidance: "宜调养脾胃，少食油腻，多食时令蔬菜" },
  { name: "惊蛰", pinyin: "Jingzhe", start: [3, 6], season: "spring", themes: ["升阳", "润燥"],
    candidates: ["桃始华", "仓庚鸣", "鹰化为鸠"],
    explanations: ["桃花开始绽放", "黄鹂鸟开始鸣叫", "老鹰变少，布谷鸟开始活跃"],
    climate: "春雷乍动，蛰虫苏醒",
    phenology: "桃始华，仓庚鸣，鹰化为鸠",
    guidance: "宜食梨润肺，多食清淡，护肝阳" },
  { name: "春分", pinyin: "Chunfen", start: [3, 21], season: "spring", themes: ["调阴阳", "养肝"],
    candidates: ["玄鸟至", "雷乃发声", "始电"],
    explanations: ["燕子从南方飞回来", "雷声开始响起", "开始出现闪电"],
    climate: "昼夜平分，阴阳相半",
    phenology: "玄鸟至，雷乃发声，始电",
    guidance: "宜饮食寒热均衡，多食时蔬，忌大寒大热" },
  { name: "清明", pinyin: "Qingming", start: [4, 5], season: "spring", themes: ["疏肝", "清润"],
    candidates: ["桐始华", "田鼠化为鴽", "虹始见"],
    explanations: ["桐树开始开花", "田鼠躲入地下，鹌鹑类小鸟开始活跃", "雨后开始出现彩虹"],
    climate: "天清地明，桐花盛开",
    phenology: "桐始华，田鼠化为鴽，虹始见",
    guidance: "宜食柔肝养肺之物，如荠菜、菠菜、春笋" },
  { name: "谷雨", pinyin: "Guyu", start: [4, 20], season: "spring", themes: ["健脾", "祛湿"],
    candidates: ["萍始生", "鸣鸠拂其羽", "戴胜降于桑"],
    explanations: ["水面上开始生浮萍", "布谷鸟梳理羽毛，鸣叫着催促农事", "戴胜鸟飞到桑树上栖息"],
    climate: "湿气渐重，雨水充沛",
    phenology: "萍始生，鸣鸠拂其羽，戴胜降于桑",
    guidance: "宜食薏米、赤小豆健脾化湿" },
  { name: "立夏", pinyin: "Lixia", start: [5, 6], season: "summer", themes: ["养心", "清淡"],
    candidates: ["蝼蝈鸣", "蚯蚓出", "王瓜生"],
    explanations: ["蝼蛄和青蛙开始鸣叫", "蚯蚓从土里钻出来", "王瓜（药用瓜类）开始生长"],
    climate: "蝼蝈鸣叫，暑气初临",
    phenology: "蝼蝈鸣，蚯蚓出，王瓜生",
    guidance: "宜养心安神，食苦味，忌过食生冷" },
  { name: "小满", pinyin: "Xiaoman", start: [5, 21], season: "summer", themes: ["清热", "祛湿"],
    candidates: ["苦菜秀", "靡草死", "麦秋至"],
    explanations: ["苦菜开花茂盛", "喜阴的细草在强光下枯死", "麦子逐渐成熟，迎来麦收的秋"],
    climate: "湿热渐盛，麦粒渐满",
    phenology: "苦菜秀，靡草死，麦秋至",
    guidance: "宜食苦瓜、绿豆、冬瓜" },
  { name: "芒种", pinyin: "Mangzhong", start: [6, 6], season: "summer", themes: ["清热", "祛湿", "生津"],
    candidates: ["螳螂生", "鵙始鸣", "反舌无声"],
    explanations: ["螳螂破壳而出", "伯劳鸟开始在枝头鸣叫", "反舌鸟（百舌鸟）停止鸣叫"],
    climate: "湿热交蒸，阴气渐盛",
    phenology: "螳螂生，鵙始鸣，反舌无声",
    guidance: "宜清补，食薏米、鸭肉、青梅" },
  { name: "夏至", pinyin: "Xiazhi", start: [6, 21], season: "summer", themes: ["养心", "生津"],
    candidates: ["鹿角解", "蜩始鸣", "半夏生"],
    explanations: ["鹿角开始脱落", "蝉开始鸣叫", "药草半夏开始生长"],
    climate: "阳气至盛，昼长夜短",
    phenology: "鹿角解，蜩始鸣，半夏生",
    guidance: "宜食酸咸生津，多饮汤水" },
  { name: "小暑", pinyin: "Xiaoshu", start: [7, 7], season: "summer", themes: ["清暑", "益气"],
    candidates: ["温风至", "蟋蟀居壁", "鹰始鸷"],
    explanations: ["热风开始吹来", "蟋蟀躲到墙角乘凉", "幼鹰开始学习搏击长空"],
    climate: "温风至，热风初盛",
    phenology: "温风至，蟋蟀居壁，鹰始鸷",
    guidance: "宜食莲子、绿豆、丝瓜，清暑益气" },
  { name: "大暑", pinyin: "Dashu", start: [7, 23], season: "summer", themes: ["清热", "解暑"],
    candidates: ["腐草为萤", "土润溽暑", "大雨时行"],
    explanations: ["腐烂的草丛中萤火虫孵化飞舞", "土地湿润，暑气闷热蒸腾", "大雨时常降临"],
    climate: "酷热当头，雷雨频发",
    phenology: "腐草为萤，土润溽暑，大雨时行",
    guidance: "宜食冬瓜、苦瓜、西瓜、绿豆汤" },
  { name: "立秋", pinyin: "Liqiu", start: [8, 8], season: "autumn", themes: ["润燥", "养肺"],
    candidates: ["凉风至", "白露降", "寒蝉鸣"],
    explanations: ["凉爽的风开始吹来", "清晨开始出现白色露水", "寒蝉开始鸣叫"],
    climate: "凉风至，暑湿未消",
    phenology: "凉风至，白露降，寒蝉鸣",
    guidance: "宜食百合、银耳、莲藕润燥" },
  { name: "处暑", pinyin: "Chushu", start: [8, 23], season: "autumn", themes: ["润燥", "养阴"],
    candidates: ["鹰乃祭鸟", "天地始肃", "禾乃登"],
    explanations: ["老鹰大量捕鸟，像祭祀一样排列猎物", "天地间开始出现肃杀之气", "禾谷成熟，可以收割登场"],
    climate: "天地始肃，暑气渐退",
    phenology: "鹰乃祭鸟，天地始肃，禾乃登",
    guidance: "宜食梨、葡萄、百合，滋阴润肺" },
  { name: "白露", pinyin: "Bailu", start: [9, 8], season: "autumn", themes: ["润肺", "养阴"],
    candidates: ["鸿雁来", "玄鸟归", "群鸟养羞"],
    explanations: ["大雁从北方飞来南方", "燕子等候鸟开始南归", "群鸟开始储存食物过冬"],
    climate: "燥气渐重，白露降",
    phenology: "鸿雁来，玄鸟归，群鸟养羞",
    guidance: "宜食梨、藕、山药、芝麻" },
  { name: "秋分", pinyin: "Qiufen", start: [9, 23], season: "autumn", themes: ["润肺", "平补"],
    candidates: ["雷始收声", "蛰虫坯户", "水始涸"],
    explanations: ["雷声渐渐停止", "冬眠的虫子开始封住洞口", "河水开始干涸"],
    climate: "昼夜平分，雷始收声",
    phenology: "雷始收声，蛰虫坯户，水始涸",
    guidance: "宜温润平补，食南瓜、栗子、芋头" },
  { name: "寒露", pinyin: "Hanlu", start: [10, 8], season: "autumn", themes: ["温润", "养阴"],
    candidates: ["鸿雁来宾", "雀入大水为蛤", "菊有黄华"],
    explanations: ["最后一批大雁飞来", "雀鸟少见，海边出现很多蛤蜊", "菊花开始绽放黄色花朵"],
    climate: "秋燥转凉，鸿雁南飞",
    phenology: "鸿雁来宾，雀入大水为蛤，菊有黄华",
    guidance: "宜食柿子、芝麻、核桃、银耳" },
  { name: "霜降", pinyin: "Shuangjiang", start: [10, 23], season: "autumn", themes: ["温补", "润肺"],
    candidates: ["豺乃祭兽", "草木黄落", "蛰虫咸俯"],
    explanations: ["豺狼捕到猎物后排列在地上", "草木枯黄落叶", "冬眠的动物全部伏藏入土"],
    climate: "草木黄落，寒气渐深",
    phenology: "豺乃祭兽，草木黄落，蛰虫咸俯",
    guidance: "宜平补，食萝卜、栗子、羊肉、柿子" },
  { name: "立冬", pinyin: "Lidong", start: [11, 7], season: "winter", themes: ["温补", "藏阳"],
    candidates: ["水始冰", "地始冻", "雉入大水为蜃"],
    explanations: ["水面开始结冰", "土地开始冻结", "野鸡少见，海边出现大蛤蜊"],
    climate: "水始冰，阳气潜藏",
    phenology: "水始冰，地始冻，雉入大水为蜃",
    guidance: "宜进补，食羊肉、牛肉、桂圆，温补阳气" },
  { name: "小雪", pinyin: "Xiaoxue", start: [11, 22], season: "winter", themes: ["温补", "黑色入肾"],
    candidates: ["虹藏不见", "天气上升地气下降", "闭塞而成冬"],
    explanations: ["彩虹不再出现", "天气上升，地气下降，阴阳不交", "天地闭塞不通，冬天正式开始"],
    climate: "天地闭塞，虹藏不见",
    phenology: "虹藏不见，天地不通，闭塞成冬",
    guidance: "宜食黑芝麻、黑豆、核桃、羊肉补肾" },
  { name: "大雪", pinyin: "Daxue", start: [12, 7], season: "winter", themes: ["温补", "御寒"],
    candidates: ["鹖鴠不鸣", "虎始交", "荔挺出"],
    explanations: ["寒号鸟不再鸣叫", "老虎开始有交配行为", "马兰草（荔挺）抽出新芽"],
    climate: "鹖鴠不鸣，寒气渐盛",
    phenology: "鹖鴠不鸣，虎始交，荔挺出",
    guidance: "宜御寒进补，食羊肉萝卜、牛肉炖菜、姜枣" },
  { name: "冬至", pinyin: "Dongzhi", start: [12, 22], season: "winter", themes: ["大补", "藏精"],
    candidates: ["蚯蚓结", "麋角解", "水泉动"],
    explanations: ["蚯蚓在土里蜷缩打结", "麋鹿的角开始脱落", "井水泉水开始有温热流动"],
    climate: "一阳初生，阴极阳回",
    phenology: "蚯蚓结，麋角解，水泉动",
    guidance: "宜食饺子、汤圆、羊肉、当归生姜" },
  { name: "小寒", pinyin: "Xiaohan", start: [1, 6], season: "winter", themes: ["温阳", "暖胃"],
    candidates: ["雁北乡", "鹊始巢", "雉始雊"],
    explanations: ["大雁开始向北飞（感知阳气）", "喜鹊开始筑巢", "野鸡开始鸣叫求偶"],
    climate: "数九寒天，阳气初生",
    phenology: "雁北乡，鹊始巢，雉始雊",
    guidance: "宜食腊八粥、羊肉、桂圆温阳" },
  { name: "大寒", pinyin: "Dahan", start: [1, 20], season: "winter", themes: ["温补", "暖中"],
    candidates: ["鸡始乳", "征鸟厉疾", "水泽腹坚"],
    explanations: ["母鸡开始孵小鸡", "猛禽捕食更加凶猛迅疾", "河湖水域中央冻得很结实"],
    climate: "寒极生暖，水泽腹坚",
    phenology: "鸡始乳，征鸟厉疾，水泽腹坚",
    guidance: "宜食八宝饭、糯米、姜葱羊汤" },
];

// ==========================================================
// 节气精确计算（21 世纪通用，误差 ≤ 1 天）
// 公式: day = floor(Y * 0.2422 + C) - floor((Y - 1) / 4)
// Y 为年份后两位；C 为节气常数（21 世纪 2000–2099 适用）
// 附部分历年特例校正（民间天文常用表）
// 参考：寿星万年历、紫金山天文台节气表
// ==========================================================

// 节气顺序按公历从小寒（1月）开始
const TERM_C_21: Record<string, number> = {
  小寒: 5.4055, 大寒: 20.12, 立春: 3.87, 雨水: 18.73,
  惊蛰: 5.63, 春分: 20.646, 清明: 4.81, 谷雨: 20.1,
  立夏: 5.52, 小满: 21.04, 芒种: 5.678, 夏至: 21.37,
  小暑: 7.108, 大暑: 22.83, 立秋: 7.5, 处暑: 23.13,
  白露: 7.646, 秋分: 23.042, 寒露: 8.318, 霜降: 23.438,
  立冬: 7.438, 小雪: 22.36, 大雪: 7.18, 冬至: 21.94,
};

// 已知历年特例：[节气, 年, 偏移]（偏移 -1 表示比公式早 1 天）
const TERM_EXCEPTIONS: Array<[string, number, number]> = [
  ["雨水", 2026, -1], ["春分", 2084, 1],
  ["小满", 2008, 1], ["夏至", 1928, 1], ["小暑", 1925, 1], ["小暑", 2016, 1],
  ["大暑", 2002, 1], ["立秋", 2002, 1],
  ["白露", 1927, 1], ["秋分", 2089, 1],
  ["寒露", 2089, 1],
  ["霜降", 2089, 1],
  ["立冬", 2089, 1], ["小雪", 1978, 1], ["大雪", 1954, 1],
  ["冬至", 1918, -1], ["冬至", 2021, -1],
  ["小寒", 2019, -1], ["小寒", 1982, 1],
  ["大寒", 2082, 1],
];

// 节气在公历的月份（与 SOLAR_TERMS.start[0] 一致）
const TERM_MONTH: Record<string, number> = Object.fromEntries(
  SOLAR_TERMS.map((t) => [t.name, t.start[0]]),
);

export function getSolarTermDate(name: string, year: number): Date {
  const C = TERM_C_21[name];
  const Y = year % 100;
  let day = Math.floor(Y * 0.2422 + C) - Math.floor((Y - 1) / 4);
  for (const [n, y, off] of TERM_EXCEPTIONS) {
    if (n === name && y === year) day += off;
  }
  const month = TERM_MONTH[name];
  return new Date(year, month - 1, day);
}

// 按节气名顺序返回当年所有节气日期（按公历升序，含跨年小寒大寒）
function getYearTerms(year: number): Array<{ name: string; date: Date; meta: SolarTerm }> {
  return SOLAR_TERMS.map((t) => ({
    name: t.name,
    date: getSolarTermDate(t.name, year),
    meta: t,
  })).sort((a, b) => a.date.getTime() - b.date.getTime());
}

export function getCurrentSolarTerm(date = new Date()): SolarTerm {
  const year = date.getFullYear();
  const terms = getYearTerms(year);
  // 找到最后一个 <= date 的节气
  let current = terms[0];
  for (const t of terms) {
    if (t.date.getTime() <= date.getTime()) current = t;
    else break;
  }
  // 若早于本年第一个节气（小寒），则属于上一年的大寒
  if (date.getTime() < terms[0].date.getTime()) {
    const prevTerms = getYearTerms(year - 1);
    return prevTerms[prevTerms.length - 1].meta;
  }
  return current.meta;
}

export function getNextSolarTerm(date = new Date()): SolarTerm {
  const current = getCurrentSolarTerm(date);
  const idx = SOLAR_TERMS.findIndex((t) => t.name === current.name);
  return SOLAR_TERMS[(idx + 1) % SOLAR_TERMS.length];
}

// 当前节气起始日期
export function getCurrentTermStartDate(date = new Date()): Date {
  const term = getCurrentSolarTerm(date);
  let year = date.getFullYear();
  // 大寒跨年场景：1 月初仍属上一年大寒
  let start = getSolarTermDate(term.name, year);
  if (start.getTime() > date.getTime()) {
    start = getSolarTermDate(term.name, year - 1);
  }
  return start;
}

// 获取当前节气第几候（1/2/3），每候约 5 天，基于真实节气起始日
export function getCurrentHou(date = new Date()): { index: 1 | 2 | 3; name: string; explanation: string } {
  const term = getCurrentSolarTerm(date);
  const start = getCurrentTermStartDate(date);
  const days = Math.floor((date.getTime() - start.getTime()) / 86400000);
  const idx = (Math.min(2, Math.max(0, Math.floor(days / 5))) as 0 | 1 | 2);
  return { index: (idx + 1) as 1 | 2 | 3, name: term.candidates[idx], explanation: term.explanations[idx] };
}

