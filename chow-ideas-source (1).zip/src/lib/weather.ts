import type { Region } from "./solar-terms";

export type GeoCity = {
  name: string;
  latitude: number;
  longitude: number;
  admin1?: string;
  country?: string;
  region: Region;
};

export type WeatherSnapshot = {
  tempC: number;
  humidity: number;
  precipitation: number;
  weatherCode: number;
  windSpeed: number;
  cityLabel: string;
};

export const REGION_LABELS: Record<Region, string> = {
  northeast: "东北",
  north: "华北",
  jiangnan: "江南",
  south: "华南",
  southwest: "西南",
  northwest: "西北",
  central: "华中",
  hongkong: "港澳",
  taiwan: "台湾",
  overseas: "海外",
};

export const PRESET_CITIES: GeoCity[] = [
  // 东北
  { name: "哈尔滨", latitude: 45.75, longitude: 126.65, admin1: "黑龙江省", region: "northeast" },
  { name: "长春", latitude: 43.8171, longitude: 125.3235, admin1: "吉林省", region: "northeast" },
  { name: "沈阳", latitude: 41.8057, longitude: 123.4315, admin1: "辽宁省", region: "northeast" },
  { name: "大连", latitude: 38.914, longitude: 121.6147, admin1: "辽宁省", region: "northeast" },
  // 华北
  { name: "北京", latitude: 39.9042, longitude: 116.4074, region: "north" },
  { name: "天津", latitude: 39.3434, longitude: 117.3616, region: "north" },
  { name: "济南", latitude: 36.6512, longitude: 117.1201, admin1: "山东省", region: "north" },
  { name: "青岛", latitude: 36.0671, longitude: 120.3826, admin1: "山东省", region: "north" },
  { name: "石家庄", latitude: 38.0428, longitude: 114.5149, admin1: "河北省", region: "north" },
  // 西北
  { name: "西安", latitude: 34.3416, longitude: 108.9398, admin1: "陕西省", region: "northwest" },
  { name: "兰州", latitude: 36.0611, longitude: 103.8343, admin1: "甘肃省", region: "northwest" },
  { name: "乌鲁木齐", latitude: 43.8256, longitude: 87.6168, admin1: "新疆", region: "northwest" },
  // 华中
  { name: "郑州", latitude: 34.7466, longitude: 113.6253, admin1: "河南省", region: "central" },
  { name: "武汉", latitude: 30.5928, longitude: 114.3055, admin1: "湖北省", region: "central" },
  { name: "长沙", latitude: 28.2282, longitude: 112.9388, admin1: "湖南省", region: "central" },
  // 江南
  { name: "上海", latitude: 31.2304, longitude: 121.4737, region: "jiangnan" },
  { name: "杭州", latitude: 30.2741, longitude: 120.1551, admin1: "浙江省", region: "jiangnan" },
  { name: "南京", latitude: 32.0603, longitude: 118.7969, admin1: "江苏省", region: "jiangnan" },
  { name: "苏州", latitude: 31.299, longitude: 120.5853, admin1: "江苏省", region: "jiangnan" },
  // 华南
  { name: "广州", latitude: 23.1291, longitude: 113.2644, admin1: "广东省", region: "south" },
  { name: "深圳", latitude: 22.5431, longitude: 114.0579, admin1: "广东省", region: "south" },
  { name: "厦门", latitude: 24.4798, longitude: 118.0894, admin1: "福建省", region: "south" },
  { name: "福州", latitude: 26.0745, longitude: 119.2965, admin1: "福建省", region: "south" },
  // 西南
  { name: "成都", latitude: 30.5728, longitude: 104.0668, admin1: "四川省", region: "southwest" },
  { name: "重庆", latitude: 29.4316, longitude: 106.9123, region: "southwest" },
  { name: "昆明", latitude: 25.0389, longitude: 102.7183, admin1: "云南省", region: "southwest" },
  { name: "贵阳", latitude: 26.6470, longitude: 106.6302, admin1: "贵州省", region: "southwest" },
  // 港澳台
  { name: "香港", latitude: 22.3193, longitude: 114.1694, region: "hongkong" },
  { name: "澳门", latitude: 22.1987, longitude: 113.5439, region: "hongkong" },
  { name: "台北", latitude: 25.0330, longitude: 121.5654, admin1: "台湾", region: "taiwan" },
  { name: "高雄", latitude: 22.6273, longitude: 120.3014, admin1: "台湾", region: "taiwan" },
  // 海外（举例，搜索可加任意城市）
  { name: "新加坡", latitude: 1.3521, longitude: 103.8198, country: "新加坡", region: "overseas" },
  { name: "东京", latitude: 35.6762, longitude: 139.6503, country: "日本", region: "overseas" },
  { name: "纽约", latitude: 40.7128, longitude: -74.0060, country: "美国", region: "overseas" },
  { name: "旧金山", latitude: 37.7749, longitude: -122.4194, country: "美国", region: "overseas" },
  { name: "伦敦", latitude: 51.5074, longitude: -0.1278, country: "英国", region: "overseas" },
  { name: "悉尼", latitude: -33.8688, longitude: 151.2093, country: "澳大利亚", region: "overseas" },
];

// =========== 根据省份/国家推断菜系地域 ===========
const PROVINCE_REGION: Record<string, Region> = {
  黑龙江: "northeast", 吉林: "northeast", 辽宁: "northeast",
  北京: "north", 天津: "north", 河北: "north", 山东: "north", 山西: "north", 内蒙古: "north",
  陕西: "northwest", 甘肃: "northwest", 青海: "northwest", 宁夏: "northwest", 新疆: "northwest",
  河南: "central", 湖北: "central", 湖南: "central", 江西: "central", 安徽: "central",
  上海: "jiangnan", 江苏: "jiangnan", 浙江: "jiangnan",
  广东: "south", 广西: "south", 福建: "south", 海南: "south",
  四川: "southwest", 重庆: "southwest", 云南: "southwest", 贵州: "southwest", 西藏: "southwest",
  香港: "hongkong", 澳门: "hongkong",
  台湾: "taiwan",
};

export function inferRegion(opts: { admin1?: string; countryCode?: string; country?: string }): Region {
  const { admin1, countryCode, country } = opts;

  // 港澳台单独识别
  if (countryCode === "HK" || countryCode === "MO") return "hongkong";
  if (countryCode === "TW") return "taiwan";

  // 中国大陆：countryCode 优先（中文反向地理常返回"中华人民共和国"，不含"中国"子串）
  const isChina =
    countryCode === "CN" ||
    (!!country &&
      (country.includes("中国") ||
        country.includes("中华") ||
        country === "China" ||
        country === "PRC"));

  // 非中国地区
  if (countryCode && !isChina) {
    return "overseas";
  }
  if (!countryCode && country && !isChina) {
    if (country.includes("香港") || country.includes("澳门")) return "hongkong";
    if (country.includes("台湾")) return "taiwan";
    return "overseas";
  }

  // 中国大陆：按省份关键字匹配
  if (admin1) {
    for (const key of Object.keys(PROVINCE_REGION)) {
      if (admin1.includes(key)) return PROVINCE_REGION[key];
    }
  }
  return "central"; // 兜底
}

// =========== Open-Meteo 城市搜索（全球任意城市） ===========
export type GeocodeResult = {
  name: string;
  latitude: number;
  longitude: number;
  admin1?: string;
  country?: string;
  country_code?: string;
};

export async function searchCities(name: string): Promise<GeoCity[]> {
  if (!name.trim()) return [];
  const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
  url.searchParams.set("name", name.trim());
  url.searchParams.set("count", "10");
  url.searchParams.set("language", "zh");
  url.searchParams.set("format", "json");
  const r = await fetch(url.toString());
  if (!r.ok) return [];
  const j = (await r.json()) as { results?: GeocodeResult[] };
  return (j.results ?? []).map((g) => ({
    name: g.name,
    latitude: g.latitude,
    longitude: g.longitude,
    admin1: g.admin1,
    country: g.country,
    region: inferRegion({ admin1: g.admin1, countryCode: g.country_code, country: g.country }),
  }));
}

export async function fetchWeather(city: GeoCity): Promise<WeatherSnapshot> {
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", String(city.latitude));
  url.searchParams.set("longitude", String(city.longitude));
  url.searchParams.set(
    "current",
    "temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m",
  );
  url.searchParams.set("timezone", "auto");

  const r = await fetch(url.toString());
  if (!r.ok) throw new Error("天气获取失败");
  const j = await r.json();
  const c = j.current;
  return {
    tempC: c.temperature_2m,
    humidity: c.relative_humidity_2m,
    precipitation: c.precipitation,
    weatherCode: c.weather_code,
    windSpeed: c.wind_speed_10m,
    cityLabel: city.admin1 ? `${city.admin1} · ${city.name}` : city.name,
  };
}

export function weatherCodeText(code: number): string {
  const map: Record<number, string> = {
    0: "晴", 1: "晴间多云", 2: "多云", 3: "阴",
    45: "雾", 48: "雾凇",
    51: "毛毛雨", 53: "小雨", 55: "中雨",
    61: "小雨", 63: "中雨", 65: "大雨",
    71: "小雪", 73: "中雪", 75: "大雪", 77: "雪粒",
    80: "阵雨", 81: "强阵雨", 82: "暴雨",
    85: "阵雪", 86: "强阵雪",
    95: "雷雨", 96: "雷雨夹雹", 99: "强雷雨",
  };
  return map[code] ?? "—";
}
