import { PRESET_CITIES, inferRegion, type GeoCity } from "./weather";
import { getSolarTermDate, getCurrentSolarTerm, getNextSolarTerm } from "./solar-terms";

// 反向地理编码：lat/lon → 真实城市（不再吸附到 27 个预设）
// 用 BigDataCloud 免费客户端接口，无需 API Key
export async function reverseGeocodeToCity(
  lat: number,
  lon: number,
): Promise<GeoCity> {
  try {
    const url = new URL("https://api.bigdatacloud.net/data/reverse-geocode-client");
    url.searchParams.set("latitude", String(lat));
    url.searchParams.set("longitude", String(lon));
    url.searchParams.set("localityLanguage", "zh");
    const r = await fetch(url.toString());
    if (!r.ok) throw new Error("reverse geocode failed");
    const j = (await r.json()) as {
      city?: string;
      locality?: string;
      principalSubdivision?: string;
      countryName?: string;
      countryCode?: string;
    };
    const cityName = j.city || j.locality || j.principalSubdivision || "未知地点";
    const admin1 = j.principalSubdivision;
    return {
      name: cityName,
      latitude: lat,
      longitude: lon,
      admin1,
      country: j.countryName,
      region: inferRegion({
        admin1,
        countryCode: j.countryCode,
        country: j.countryName,
      }),
    };
  } catch {
    // 网络失败兜底：仍用最近预设城市
    return nearestCity(lat, lon);
  }
}


// 球面距离（km），用于"最近城市"匹配
function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export function nearestCity(lat: number, lon: number): GeoCity {
  let best = PRESET_CITIES[0];
  let bestD = Infinity;
  for (const c of PRESET_CITIES) {
    const d = haversine(lat, lon, c.latitude, c.longitude);
    if (d < bestD) {
      bestD = d;
      best = c;
    }
  }
  return best;
}

export function requestGeolocation(): Promise<{ lat: number; lon: number }> {
  return new Promise((resolve, reject) => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      reject(new Error("浏览器不支持定位"));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude, lon: p.coords.longitude }),
      (e) => reject(e),
      { timeout: 8000, maximumAge: 30 * 60 * 1000 },
    );
  });
}

// 距下一节气剩余天数 + 当前节气进度（0-1）
export function getTermProgress(date = new Date()): {
  daysToNext: number;
  nextName: string;
  progress: number;
} {
  const cur = getCurrentSolarTerm(date);
  const next = getNextSolarTerm(date);
  let nextYear = date.getFullYear();
  let nextDate = getSolarTermDate(next.name, nextYear);
  if (nextDate.getTime() <= date.getTime()) {
    nextDate = getSolarTermDate(next.name, nextYear + 1);
  }
  let curStart = getSolarTermDate(cur.name, nextYear);
  if (curStart.getTime() > date.getTime()) {
    curStart = getSolarTermDate(cur.name, nextYear - 1);
  }
  const total = nextDate.getTime() - curStart.getTime();
  const done = date.getTime() - curStart.getTime();
  const days = Math.ceil((nextDate.getTime() - date.getTime()) / 86400000);
  return {
    daysToNext: Math.max(0, days),
    nextName: next.name,
    progress: Math.min(1, Math.max(0, done / total)),
  };
}
