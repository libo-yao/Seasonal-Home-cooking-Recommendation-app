import { DISHES, type Dish, type WeatherTag } from "./dishes";
import type { Region, SolarTerm } from "./solar-terms";
import { getPhenologyIngredients } from "./phenology";

export function inferWeatherTags(opts: {
  tempC: number;
  precipitation: number;
  weatherCode: number;
  humidity: number;
  windSpeed: number;
}): WeatherTag[] {
  const tags: WeatherTag[] = [];
  const { tempC, precipitation, weatherCode, humidity, windSpeed } = opts;

  if (tempC >= 28) tags.push("hot");
  else if (tempC <= 5) tags.push("cold");
  else tags.push("mild");

  if (humidity >= 75 && tempC >= 20) tags.push("humid");
  if (humidity <= 35) tags.push("dry");

  if ([71, 73, 75, 77, 85, 86].includes(weatherCode) || (precipitation > 0 && tempC <= 0)) {
    tags.push("snow");
  } else if (precipitation > 0.3 || [51, 53, 55, 61, 63, 65, 80, 81, 82, 95].includes(weatherCode)) {
    tags.push("rainy");
  }

  if (windSpeed >= 25) tags.push("windy");

  return tags;
}

type Intent = {
  rationale: string;
  recommend: string[]; // 推荐食材关键字（菜谱命中即加分）
  avoid: string[]; // 应避食材关键字（菜谱命中即排除）
  phenology: string[]; // 当下"候"对应的关键食材（最高优先级）
  phenologyName: string;
};

function buildIntent(
  term: SolarTerm,
  tags: WeatherTag[],
  region: Region,
  houIndex: 1 | 2 | 3 = 1,
): Intent {
  const has = (t: WeatherTag) => tags.includes(t);
  const southern = region === "south" || region === "southwest" || region === "jiangnan";
  const northern = region === "northeast" || region === "northwest" || region === "north";

  let weatherWord = "";
  let advice = "";
  let recommend: string[] = [];
  // 默认避食：所有"清热/祛湿/润燥"场景都禁温补辛热
  const HOT_TONIC = ["羊肉", "桂圆", "当归", "肉桂", "花椒", "辣椒", "牛肉"];
  const COLD_FOOD = ["绿豆", "苦瓜", "西瓜", "雪梨", "冰糖", "莲藕生"];
  let avoid: string[] = [];

  if (has("hot") && has("humid")) {
    weatherWord = "湿热";
    advice = southern ? "宜清热祛湿，食绿豆、冬瓜、薏米" : "宜清补祛湿，食薏米、苦瓜、绿豆";
    recommend = ["绿豆", "冬瓜", "薏米", "苦瓜", "丝瓜", "扁豆"];
    avoid = HOT_TONIC;
  } else if (has("hot") && has("dry")) {
    weatherWord = "燥热";
    advice = "宜清热生津，食西瓜、银耳、雪梨";
    recommend = ["西瓜", "银耳", "雪梨", "百合", "莲子", "藕", "蜂蜜"];
    avoid = HOT_TONIC;
  } else if (has("hot")) {
    weatherWord = "暑热";
    advice = "宜清暑解热，食绿豆、苦瓜、酸梅";
    recommend = ["绿豆", "苦瓜", "酸梅", "冬瓜", "丝瓜", "莲子"];
    avoid = HOT_TONIC;
  } else if (has("cold") && has("snow")) {
    weatherWord = "冰雪";
    advice = "宜温阳御寒，食羊肉、姜枣、桂圆";
    recommend = ["羊肉", "姜", "红枣", "桂圆", "核桃", "牛肉"];
    avoid = COLD_FOOD;
  } else if (has("cold")) {
    weatherWord = "严寒";
    advice = northern ? "宜温补暖身，食牛肉、羊肉、山药" : "宜暖中补气，食羊肉、生姜、红枣";
    recommend = northern
      ? ["牛肉", "羊肉", "山药", "土豆", "白菜", "萝卜"]
      : ["羊肉", "生姜", "红枣", "山药", "鸡"];
    avoid = COLD_FOOD;
  } else if (has("rainy") && has("humid")) {
    weatherWord = "阴湿";
    advice = "宜健脾化湿，食薏米、赤小豆、山药";
    recommend = ["薏米", "赤小豆", "山药", "茯苓", "扁豆", "芡实"];
  } else if (has("rainy")) {
    weatherWord = "微雨";
    advice = "宜温润和胃，食生姜、山药、香菇";
    recommend = ["生姜", "姜", "山药", "香菇", "鸡"];
  } else if (has("snow")) {
    weatherWord = "落雪";
    advice = "宜温补抗寒，食羊肉、核桃、桂圆";
    recommend = ["羊肉", "核桃", "桂圆", "红枣", "牛肉"];
    avoid = COLD_FOOD;
  } else if (has("dry")) {
    weatherWord = "干燥";
    advice = "宜滋阴润燥，食银耳、百合、雪梨";
    recommend = ["银耳", "百合", "雪梨", "梨", "蜂蜜", "藕", "白萝卜"];
    avoid = HOT_TONIC;
  } else if (has("humid")) {
    weatherWord = "湿润";
    advice = "宜健脾祛湿，食薏米、冬瓜、扁豆";
    recommend = ["薏米", "冬瓜", "扁豆", "赤小豆", "山药"];
  } else if (has("windy")) {
    weatherWord = "风疾";
    advice = "宜润燥护肺，食梨、银耳、蜂蜜";
    recommend = ["梨", "银耳", "蜂蜜", "百合", "白萝卜"];
  } else {
    const phenologyName = term.candidates[houIndex - 1];
    const phenology = getPhenologyIngredients(phenologyName);
    const phenoTip = phenology.length > 0 ? `；物候「${phenologyName}」宜${phenology.slice(0, 3).join("、")}` : "";
    return {
      rationale: `今日${term.name}，${term.guidance}${phenoTip}。`,
      recommend: phenology,
      avoid: [],
      phenology,
      phenologyName,
    };
  }

  const phenologyName = term.candidates[houIndex - 1];
  const phenology = getPhenologyIngredients(phenologyName);
  return {
    rationale: `今日${term.name}·${weatherWord}，${advice}。物候「${phenologyName}」宜${phenology.slice(0, 3).join("、")}。`,
    recommend: [...recommend, ...phenology],
    avoid,
    phenology,
    phenologyName,
  };
}

function seededPick<T>(items: T[], seed: string): T {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return items[h % items.length];
}

export type DailyMenu = {
  soup: Dish;
  meat: Dish;
  veg: Dish;
  matchedTags: WeatherTag[];
  rationale: string;
};

function dishFitsRegion(dish: Dish, region: Region): boolean {
  return dish.regions === "all" || dish.regions.includes(region);
}

function isLocal(dish: Dish, region: Region): boolean {
  return dish.regions !== "all" && (dish.regions as Region[]).includes(region);
}

// 节气/天气硬冲突：温补 vs 暑热、清凉 vs 严寒、当令季节绝对不可错配
function conflictsWith(
  dish: Dish,
  term: SolarTerm,
  weatherTags: WeatherTag[],
): boolean {
  const has = (t: WeatherTag) => weatherTags.includes(t);
  const dw = new Set(dish.weather);

  // 当下"热/暑"：禁止温补类（cold/snow 标签的菜，如羊肉汤、当归生姜）
  if ((has("hot") || term.season === "summer") && (dw.has("cold") || dw.has("snow"))) {
    return true;
  }
  // 当下"寒/雪"：禁止清热消暑类
  if ((has("cold") || has("snow") || term.season === "winter") && dw.has("hot")) {
    return true;
  }
  // 当下"燥"：禁止本身偏湿热重补的（cold+snow 强温补）
  if (has("dry") && dw.has("cold") && dw.has("snow")) {
    return true;
  }

  // 季节硬冲突：菜只标了单一季节且与当前季节相反
  if (dish.seasons.length === 1) {
    const only = dish.seasons[0];
    const opposite =
      (only === "summer" && term.season === "winter") ||
      (only === "winter" && term.season === "summer");
    if (opposite) return true;
  }
  return false;
}

function ingredientText(dish: Dish): string {
  return dish.ingredients.join("|") + "|" + dish.reason + "|" + dish.name;
}

function matchesAny(dish: Dish, keys: string[]): boolean {
  if (keys.length === 0) return false;
  const text = ingredientText(dish);
  return keys.some((k) => text.includes(k));
}

function scoreDish(
  dish: Dish,
  term: SolarTerm,
  weatherTags: WeatherTag[],
  region: Region,
  intent: Intent,
): number {
  let score = 0;
  if (dish.seasons.includes(term.season)) score += 4;
  else score -= 1.5; // 非当令轻度扣分

  const weatherHits = dish.weather.filter((w) => weatherTags.includes(w)).length;
  score += weatherHits * 3;
  if (weatherHits === 0 && !dish.weather.includes("mild")) score -= 1;
  if (dish.weather.includes("mild")) score += 0.5;

  // 意图（rationale 推荐食材）命中：每命中一个 +4，强力对齐
  const text = ingredientText(dish);
  const intentHits = intent.recommend.filter((k) => text.includes(k)).length;
  score += intentHits * 4;

  // 物候关键食材命中：每命中一个 +6，最高优先级
  const phenologyHits = intent.phenology.filter((k) => text.includes(k)).length;
  score += phenologyHits * 6;

  if (isLocal(dish, region)) {
    score += 3;
    if (dish.availability === 1) score += 1;
  }
  score += dish.availability * 0.3;

  return score;
}

export function recommendMenu(
  term: SolarTerm,
  weatherTags: WeatherTag[],
  region: Region,
  dateKey: string,
  rerollIndex: number = 0,
  houIndex: 1 | 2 | 3 = 1,
): DailyMenu {
  const intent = buildIntent(term, weatherTags, region, houIndex);

  const pickCat = (cat: Dish["category"]): Dish => {
    const inRegion = DISHES.filter(
      (d) => d.category === cat && dishFitsRegion(d, region),
    );
    // 若本区域没有命中物候的菜，则放宽到全国菜库中物候命中者（确保物候规则可落地）
    const phenoInRegion = inRegion.filter(
      (d) => matchesAny(d, intent.phenology) && !conflictsWith(d, term, weatherTags),
    );
    const phenoAnywhere =
      intent.phenology.length > 0 && phenoInRegion.length === 0
        ? DISHES.filter(
            (d) =>
              d.category === cat &&
              matchesAny(d, intent.phenology) &&
              !conflictsWith(d, term, weatherTags) &&
              !matchesAny(d, intent.avoid),
          )
        : [];
    const all = phenoAnywhere.length > 0 ? [...inRegion, ...phenoAnywhere] : inRegion;

    // 剔除硬冲突 + 剔除"应避食材"命中
    const compatible = all.filter(
      (d) => !conflictsWith(d, term, weatherTags) && !matchesAny(d, intent.avoid),
    );
    // 兜底：避食过滤后空 → 放宽到仅天气冲突过滤；再空 → 全候选
    const fallback = all.filter((d) => !conflictsWith(d, term, weatherTags));
    const candidates =
      compatible.length > 0 ? compatible : fallback.length > 0 ? fallback : all;

    const ranked = candidates
      .map((d) => ({ d, s: scoreDish(d, term, weatherTags, region, intent) }))
      .sort((a, b) => b.s - a.s);
    if (ranked.length === 0) return DISHES.find((d) => d.category === cat)!;

    // 若本区域有物候命中菜：仅在本区域物候菜中挑（地域+物候双优）
    // 否则若有跨区物候命中菜：仅在物候命中菜中挑（物候优先于地域）
    // 否则若本地菜 ≥2 道：仅在本地菜中挑（保留地域风味）
    const phenoRankedInRegion = ranked.filter(
      (r) => isLocal(r.d, region) && matchesAny(r.d, intent.phenology),
    );
    const phenoRankedAny = ranked.filter((r) => matchesAny(r.d, intent.phenology));
    const localRanked = ranked.filter((r) => isLocal(r.d, region));
    const usable =
      phenoRankedInRegion.length >= 1
        ? phenoRankedInRegion
        : phenoRankedAny.length >= 1
          ? phenoRankedAny
          : localRanked.length >= 2
            ? localRanked
            : ranked;

    // 优先选物候命中的；其次意图命中；再次 usable
    const phenologyRanked = usable.filter((r) => matchesAny(r.d, intent.phenology));
    const intentRanked = usable.filter((r) => matchesAny(r.d, intent.recommend));
    const finalRanked =
      phenologyRanked.length >= 1
        ? phenologyRanked
        : intentRanked.length >= 2
          ? intentRanked
          : usable;

    const poolSize = Math.min(maxRerollGroups(region), finalRanked.length);
    const pool = finalRanked.slice(0, poolSize).map((r) => r.d);

    const offset = seededOffset(`${dateKey}|${cat}`, pool.length);
    return pool[(offset + rerollIndex) % pool.length];
  };

  const soup = pickCat("soup");
  const meat = pickCat("meat");
  const veg = pickCat("veg");

  return { soup, meat, veg, matchedTags: weatherTags, rationale: intent.rationale };
}

function seededOffset(seed: string, mod: number): number {
  if (mod <= 0) return 0;
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return h % mod;
}

// 计算给定地域下，三个分类都能凑出几道不重复的菜（决定"换一组"圆点数）
export function maxRerollGroups(region: Region): number {
  const cats: Dish["category"][] = ["soup", "meat", "veg"];
  let min = Infinity;
  for (const cat of cats) {
    const candidates = DISHES.filter(
      (d) => d.category === cat && dishFitsRegion(d, region),
    );
    const localCount = candidates.filter((d) => isLocal(d, region)).length;
    const usable = localCount >= 2 ? localCount : candidates.length;
    if (usable < min) min = usable;
  }
  return Math.max(1, Math.min(5, min));
}

